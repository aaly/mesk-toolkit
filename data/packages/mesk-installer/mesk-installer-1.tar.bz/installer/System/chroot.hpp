#ifndef CHROOT_HPP
#define CHROOT_HPP

#include <QObject>
#include <QProcess>

class chroot : public QObject
{
    Q_OBJECT
public:
    explicit chroot(QObject *parent = 0);
    //chroot(QObject *parent = 0);
    ~chroot();

    int setRoot(QString&);
    int prepare();
    int exec(QString);

    
signals:
    void    Done(int);
public slots:

private:
    QString root;
    QProcess mountRoot;
    int unprepare();
    
};

#endif // CHROOT_HPP
