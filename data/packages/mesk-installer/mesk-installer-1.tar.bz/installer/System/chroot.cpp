#include "chroot.hpp"
#include <QProcess>

chroot::chroot(QObject *parent) :
    QObject(parent)
{
}

/*chroot(QObject *parent = 0, QString& root)
{
    setRoot(root);
    prepare();
}*/

int chroot::setRoot(QString& croot)
{
    if (croot.size() == 0)
    {
        return 1;
    }

    root=croot;
    return 0;
}

int wait = 10000;

int chroot::prepare()
{
    //mountRoot.start("mkdir -p " + root);
    //mountRoot.waitForFinished(wait);

    mountRoot.start("mount --bind /dev " + root + "/dev");
    mountRoot.waitForFinished(wait);
    mountRoot.start("mount --bind /dev/pts " + root + "/dev/pts");
    mountRoot.waitForFinished(wait);
    mountRoot.start("mount --bind /dev/shm " + root + "/dev/shm");
    mountRoot.waitForFinished(wait);
    mountRoot.start("mount -t proc none " + root + "/proc");
    mountRoot.waitForFinished(wait);
    mountRoot.start("mount -t sysfs none " + root + "/sys");
}

int chroot::unprepare()
{
    mountRoot.start("umount " + root + "/dev/pts");
    mountRoot.waitForFinished(wait);
    mountRoot.start("umount " + root + "/dev/shm");
    mountRoot.waitForFinished(wait);
    mountRoot.start("umount " + root + "/dev");
    mountRoot.waitForFinished(wait);
    mountRoot.start("umount " + root + "/proc");
    mountRoot.waitForFinished(wait);
    mountRoot.start("umount " + root + "/sys");
    mountRoot.waitForFinished(wait);
    return 0;
}

int chroot::exec(QString comm)
{
    mountRoot.start("chroot " + root + " " + comm);
    int ret = mountRoot.waitForFinished(10000);
    emit Done(ret);
    return ret;
}

chroot::~chroot()
{
    unprepare();
}
