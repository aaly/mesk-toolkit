#include "rootCommand.hpp"

Shell::Shell(QObject *parent, QString rootpw) :
    QObject(parent)
{
}
