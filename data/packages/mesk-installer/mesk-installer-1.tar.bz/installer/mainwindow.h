#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ui_mainwindow.h"
#include "pageBase.hpp"
#include <loadingpage.hpp>

enum widgetEffects
{
    FADING =0,
    RESIZING
};

class MainWindow : public QMainWindow, private Ui::MainWindow
{
    Q_OBJECT


public:
    explicit MainWindow(QWidget *parent = 0);

    ~MainWindow();

private:

    int     messageIconWidth;
    int     messageIconHeight;
    bool    pageReady;
    int     currentPage;
    QVector<pageBase*>* pages;

    int     addPage(pageBase* page);

    int     step;


    loadingPage*    loadingpage;

public slots:
    int     addMessage(QString, int);
    int     showHelp();
    int     nextPage();
    int     prevPage();


private slots:
    int animateWidget(QWidget*, bool, int);
    int     changePage();
};

#endif // MAINWINDOW_H
