#ifndef RELEASEPAGE_H
#define RELEASEPAGE_H

#include "Pages/pageBase.hpp"
#include "ui_releasePage.h"

#include <QFile>

class releasePage : public pageBase, private Ui::releasePage
{
    Q_OBJECT

public:
    explicit releasePage(QWidget *parent = 0);
    ~releasePage();
    int     initAll();

private:
    QString releaseFilePath;
private slots:
};

#endif // RELEASEPAGE_H
