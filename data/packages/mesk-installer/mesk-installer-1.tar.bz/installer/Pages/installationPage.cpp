#include "installationPage.hpp"
#include "ui_installationPage.h"
#include <Pages/packagesPage.hpp>
#include <Pages/diskPage.hpp>
#include <Pages/timepage.hpp>

#include <QTimer>
#include <QPixmap>

#include <QMessageBox>

installationPage::installationPage(QWidget *parent) :
pageBase(parent)
{
    setupUi(this);
    slidesDir = "slides/"+lang;
    installationRoot = "/mnt/root/";
    Root = new chroot(this);
    Root->setRoot(installationRoot);
    Root->prepare();

    slideStep=0;
}

installationPage::~installationPage()
{
}


int installationPage::initAll()
{
    pageBase::initAll();
    emit Status(tr("Loading slides"), BUSY);
    initSlideShow();
    emit Ready();

    install();
    emit Done(true);

    return 0;
}

int installationPage::initSlideShow()
{

    QDir dir(slidesDir);

    foreach (const QString &fileName, dir.entryList(QDir::Files))
    {
        QString absolutePath = dir.absoluteFilePath(fileName);
        slides.push_back(QPixmap(absolutePath));
    }

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(slide()));
    timer->start(1000);
}

int installationPage::slide()
{
    displayLabel->setPixmap(slides.at(slideStep));
    slideStep++;
    if (slideStep > slides.count()-1)
    {
        slideStep=0;
    }
    return slideStep;
}

int installationPage::install()
{
    // mount the root partition
    diskPage* dpage = (diskPage*)getDependency("Disk");
    QProcess mountRoot;
    mountRoot.start("mount " + dpage->rootPartition + " " + installationRoot);
    mountRoot.waitForFinished(10000);

    installPackages();
    generateKernel();
    installationProgressBar->setValue(90);
    generateLocales();
    installationProgressBar->setValue(100);

    mountRoot.start("umount " + dpage->rootPartition + " " + installationRoot);
}


int installationPage::installPackages()
{

    packagesPage* ppage = (packagesPage*)getDependency("Packages");
    QVector<meskPackage>    packages = ppage->getSelectedPackages();

    for (int i=0; i < packages.count(); i++)
    {
        //setProgress();
        setAction(tr("installing package: ")+packages.at(i).Name+"\n"+tr("size: ")+packages.at(i).strSize);
        for ( int k=0; k < packages.at(i).packageFiles.count(); k++)
        {
            Root->exec("cp -rf " + packages.at(i).packageFiles.at(k) + " " + installationRoot);
            installationProgressBar->setValue((k*80)/packages.at(i).packageFiles.count());
        }
    }

    setAction(tr("updating original packages files"));
    QFile overlayFiles;
    overlayFiles.setFileName("/install/overlayfiles");
    QString ovfile;
    while (!overlayFiles.atEnd())
    {
        ovfile=overlayFiles.readLine();
        Root->exec("cp -rf " + ovfile+".mesksave" + " " + installationRoot+ovfile);
    }

    setAction(tr("uninstalling packages"));
    //mountRoot.start("cp -rf " + packages.at(i).packageFiles.at(k) + " /mnt/root/"); ;
    // remove uninstalled packages so that they are removed from local db :D
    // use pacman's option --dbonly
    return 0;
}

int installationPage::generateKernel()
{
    //generate kernel images and stuff
    setAction(tr("generating kernel initramfs"));
    return Root->exec("mkinitcpio -g /boot/mesk.img ");
}

int installationPage::generateLocales()
{
    setAction(tr("generating system locales"));

    // generate locales with locale-gen
    timePage* tpage = (timePage*)getDependency("Time");
    QString locales = tpage->getLocales();
    QFile localesfile;
    Root->exec("mv /etc/locale.gen /etc/locale.gen.install");
    localesfile.open(QIODevice::Append);
    localesfile.setFileName(installationRoot+"/etc/locale.gen");
    localesfile.write(locales.toUtf8());
    localesfile.flush();
    localesfile.close();
    return Root->exec("locale-gen");
}


int installationPage::setAction(const QString& action)
{
    actionLabel->setText(action);
    return 0;
}
