#include "configurationPage.hpp"
#include "ui_configurationPage.h"

configurationPage::configurationPage(QWidget *parent) :
    pageBase(parent){

    setupUi(this);
}

configurationPage::~configurationPage()
{
}
