#include "diskPage.hpp"
#include <QComboBox>
#include <Delegates/progressbarDelegate.hpp>

#include <QTreeWidget>
#include <QTreeWidgetItem>

diskPage::diskPage(QWidget *parent) :
    pageBase(parent)
{
    setupUi(this);

    currentHard = 0;

    filesystemComboBox->setEnabled(false);
    formatCheckBox->setEnabled(false);
    labelLineEdit->setEnabled(false);
    mountComboBox->setEnabled(false);

    formatToolsFilePath = "config/formattools.conf";
    labelToolsFilePath =  "config/labeltools.conf";

    pageName = tr("Disks Page");
    pageHelpMessage = tr("");

    populatePartedDrives(disks);

    for( int r=0; r<disks.size(); ++r )
    {
	QIcon dicon;

	// deprecated LOL
	if(disks[r].getTransport() == "ide" ||
	   disks[r].getTransport() == "scsi" ||
	   disks[r].getTransport() == "ataraid")
	{
	    dicon = QIcon("Icons/drive-harddisk.png");
	}
	else if(disks[r].getTransport() == "sdmmc")
	{
            dicon = QIcon("Icons/media-flash-smart-media.png");
	}
	else
	{
	    dicon = QIcon("Icons/drive-removable-media.png");
	}

	disksList->addItem(dicon,
			   disks[r].getModel() + " (" + disks[r].getSize() + ")");

	QStandardItemModel* partitionsTreeModel =
		new QStandardItemModel(disks[r].getPartitions().size(), 5, this);

    partitionsTreeModel->setHeaderData(0, Qt::Horizontal, tr("Label"));
    partitionsTreeModel->setHeaderData(1, Qt::Horizontal, tr("Partition"));
        partitionsTreeModel->setHeaderData(2, Qt::Horizontal, tr("Mount point"));
        partitionsTreeModel->setHeaderData(3, Qt::Horizontal, tr("File system"));
        partitionsTreeModel->setHeaderData(4, Qt::Horizontal, tr("Size"));

	for(int i =0; i < disks[r].getPartitions().size(); i++)
	{
	    partitionsTreeModel->setItem(i, 0,
                                          new QStandardItem(disks[r].getPartitions()[i].getLabel()));

	    partitionsTreeModel->setItem(i, 1,
					  new QStandardItem(disks[r].getPartitions()[i].getdevPath()));
	    partitionsTreeModel->setItem(i, 2,
                                          new QStandardItem(""));
	    partitionsTreeModel->setItem(i, 3,
					  new QStandardItem(disks[r].getPartitions()[i].getFSType()));
	    partitionsTreeModel->setItem(i, 4,
                                          new QStandardItem(disks[r].getPartitions()[i].getSize()));


            QVector<Partition> partitions = disks[r].getPartitions()[i].getPartitions();

            if (partitions.count() > 0)
	    {
                partitionsTreeModel->item(i, 3)->setText(tr("Extended"));
                for (int j = 0; j < partitions.count(); j++)
		{
                    partitionsTreeModel->item(i, 0)->setChild(j, 0,
                                                              new QStandardItem(partitions[j].getLabel()));
                    partitionsTreeModel->item(i, 0)->setChild(j, 1,
                                                              new QStandardItem(partitions[j].getdevPath()));
                    partitionsTreeModel->item(i, 0)->setChild(j, 2,
							      new QStandardItem(""));
                    partitionsTreeModel->item(i, 0)->setChild(j, 3,
							      new QStandardItem(partitions[j].getFSType()));
                    partitionsTreeModel->item(i, 0)->setChild(j, 4,
                                                              new QStandardItem(partitions[j].getSize()));
		}
	    }
	}
	partitionsTreeModels.push_back(partitionsTreeModel);
    }

    partitionsTreeView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    partitionsTreeView->setSelectionBehavior(QAbstractItemView::SelectRows);
    partitionsTreeView->setSelectionMode(QAbstractItemView::SingleSelection);
    partitionsTreeView->setModel(partitionsTreeModels[0]);

    connect(disksList, SIGNAL(currentIndexChanged(int)),
	    this, SLOT(refreshPartitionViews(int)));
    connect(formatCheckBox, SIGNAL(clicked(bool)), this, SLOT(formatSelected(bool)));
    connect(partitionsTreeView, SIGNAL(clicked(QModelIndex)), this, SLOT(enableOperations(QModelIndex)));
    connect(applyPushButton, SIGNAL(clicked()), this, SLOT(applyActions()));
    connect(labelLineEdit, SIGNAL(textChanged(QString)), this, SLOT(changeLabel(QString)));
    connect(mountComboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(changeMountPoint(int)));
    connect(filesystemComboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(changeFilesystem()));
    connect(resetPushButton, SIGNAL(clicked()), this, SLOT(reset()));

    connect(addPushButton, SIGNAL(clicked()), this, SLOT(addAction()));
    connect(removePushButton, SIGNAL(clicked()), this, SLOT(removeAction()));

    initFormatTools();
    initLabelTools();

    mountPoints.push_back(tr("None"));
    mountPoints.push_back("/");
    mountPoints.push_back("/boot");
    mountPoints.push_back("/usr");
    mountPoints.push_back("/home");
    mountPoints.push_back("/opt");

    for ( int i =0; i < mountPoints.count(); i++)
    {
        mountComboBox->addItem(mountPoints.at(i));
    }

   /* QVector<QString> filesystems =  initFileSystems();

    for ( unsigned int i =0; i < filesystems.count(); i++)
    {
        filesystemComboBox->addItem(filesystems.at(i));
    }
    */

    availableFileSystems = initFileSystems2();

    for ( int i =0; i < availableFileSystems.count(); i++)
    {
        filesystemComboBox->addItem(availableFileSystems.at(i).second);
    }

    rootPartition = "";
}

diskPage::~diskPage()
{
}

int diskPage::initFormatTools()
{
    QFile file(formatToolsFilePath);

    if (!file.open(QFile::ReadOnly|QFile::Text))
    {
         return 1;
    }

    QTextStream inStream(&file);

    QString line = inStream.readLine();

    while (!line.isNull())
    {
        formatTools.insert(line.mid(0, line.indexOf(' ')),
                           line.mid(line.indexOf(' '), line.size()-line.indexOf(' ')+1));
        line = inStream.readLine();
    }
    return 0;
}

int diskPage::initLabelTools()
{
    QFile file(labelToolsFilePath);

    if (!file.open(QFile::ReadOnly|QFile::Text))
    {
         return 1;
    }

    QTextStream inStream(&file);

    QString line = inStream.readLine();

    while (!line.isNull())
    {
        labelTools.insert(line.mid(0, line.indexOf(' ')),
                           line.mid(line.indexOf(' '), line.size()-line.indexOf(' ')+1));
        line = inStream.readLine();
    }
    return 0;
}

QList<Drive> diskPage::getDisks()
{
    return disks;
}



int diskPage::refreshPartitionViews(int x)
{
    partitionsTreeView->setModel(partitionsTreeModels[x]);
    currentHard = x;
    return 0;
}


int diskPage::formatSelected(bool cond)
{
    filesystemComboBox->setEnabled(cond);
    return 0;
}

QString diskPage::getText(int row)
{
    QString text;
    QModelIndex index = partitionsTreeView->currentIndex();
    QModelIndex parent = index.parent();

    if (parent.isValid())
    {
        text = partitionsTreeModels[currentHard]->item(parent.row())->child(index.row(), row)->text();
    }
    else
    {
        text = partitionsTreeModels[currentHard]->item(index.row(), row)->text();
    }

    return text;
}


Partition diskPage::getCurrentPartition()
{
    QModelIndex index = partitionsTreeView->currentIndex();
    QModelIndex parent = index.parent();

    if (parent.isValid())
    {
        return disks[currentHard].getPartitions()[parent.row()].getPartitions()[index.row()];
    }

    return disks[currentHard].getPartitions()[index.row()];
}

int diskPage::enableOperations(QModelIndex index)
{
    labelLineEdit->setText("");
    formatCheckBox->setChecked(false);

    QString fs = getText(FILESYSTEM);

    if(fs != "Extended")
    {
        mountComboBox->setEnabled(true);
        formatCheckBox->setEnabled(true);
        labelLineEdit->setEnabled(true);
    }
    else
    {
        formatCheckBox->setEnabled(false);
        labelLineEdit->setEnabled(false);
        mountComboBox->setEnabled(false);

    }

    /*if(formatTools.find(fs) == formatTools.end())
    {
        formatCheckBox->setEnabled(false);
    }
    else
    {
        formatCheckBox->setEnabled(true);
    }

    if(labelTools.find(fs) == labelTools.end())
    {
        labelLineEdit->setEnabled(false);
    }
    else
    {
        labelLineEdit->setEnabled(true);
    }*/

    return 0;
}

int diskPage::changeLabel(QString label)
{
    if (label == "")
    {
        return 1;
    }
    //partitionsTreeModels[currentHard]->item()
    return 0;
}

int diskPage::changeMountPoint(int index)
{
    return 0;
}


int diskPage::changeFilesystem()
{
    return 0;
}

int diskPage::hasAction(Partition& part, int Action)
{
    for (int i =0; i < diskActions.count(); i++)
    {
        if(diskActions[i].Action == Action &&
           diskActions[i].partition.getdevPath() == part.getdevPath())
        {
            return i;
        }
    }
    return -1;
}

int diskPage::addAction()
{
    if(formatCheckBox->isChecked())
    {
        partitionAction pAction;
        pAction.Action = PFORMAT;
        pAction.partition = getCurrentPartition();
        pAction.Value = filesystemComboBox->currentText();
        int index = hasAction(pAction.partition, pAction.Action);
        if( index == -1)
        //if( hasAction(pAction.partition, pAction.Action) == -1)
        {
            diskActions.push_back(pAction);
            QString text = tr("Format : ") + pAction.partition.getdevPath() + tr(" With ") + pAction.Value;
            QListWidgetItem* item = new QListWidgetItem(text, actionsListWidget);
            item->setTextColor(Qt::red);
        }
        else
        {
            QString message = diskActions[index].partition.getdevPath() + tr(" will already be formatted with ") +
                                diskActions[index].Value;
            emit Status(message, WARNING);
        }
    }

    if(!labelLineEdit->text().isEmpty())
    {
        partitionAction pAction;
        pAction.Action = PLABEL;
        pAction.partition = getCurrentPartition();
        pAction.Value = labelLineEdit->text();
        int index = hasAction(pAction.partition, pAction.Action);
        if( index == -1)
        {
            diskActions.push_back(pAction);
            QString text = tr("Label   : ") + pAction.partition.getdevPath() + tr(" With ") + pAction.Value;
            QListWidgetItem* item = new QListWidgetItem(text, actionsListWidget);
            item->setTextColor(Qt::darkYellow);
        }
        else
        {
            QString message = diskActions[index].partition.getdevPath() + tr(" will be already labled with ") +
                                diskActions[index].Value;
            emit Status(message, WARNING);
        }
    }

    if(mountComboBox->itemText(mountComboBox->currentIndex()) != "None")
    {
        partitionAction pAction;
        pAction.Action = PMOUNT;
        pAction.partition = getCurrentPartition();
        pAction.Value = mountComboBox->itemText(mountComboBox->currentIndex());
        int index = hasAction(pAction.partition, pAction.Action);
        QString message;
        for (int i =0; i < diskActions.size(); i++)
        {

            if ( diskActions.at(i).Action == PMOUNT)
            {
                if ( diskActions.at(i).Value == mountComboBox->itemText(mountComboBox->currentIndex()))
                {
                    message =  diskActions[i].partition.getdevPath() + tr("will already be mounted to :") + pAction.Value;
                    index = -1;
                }
            }
        }

        if( index == -1)
        {
            diskActions.push_back(pAction);
            QString text = tr("Mount   : ") + pAction.partition.getdevPath() + tr(" To ") + pAction.Value;
            QListWidgetItem* item = new QListWidgetItem(text, actionsListWidget);
            item->setTextColor(Qt::darkCyan);

            if(pAction.Value == "/")
            {
                rootPartition = getCurrentPartition().getdevPath();
            }
        }
        else
        {
            message = diskActions[index].partition.getdevPath() + tr(" will be already mounted to ") +
                                diskActions[index].Value;
            emit Status(message, WARNING);
        }
    }

    labelLineEdit->setText("");
    formatCheckBox->setChecked(false);
    mountComboBox->setCurrentIndex(0);

    return 0;
}

int diskPage::removeAction()
{
    if (! actionsListWidget->count() > 0)
    {
        return 1;
    }

    if (diskActions.at(actionsListWidget->currentRow()).Action == PMOUNT &&
            diskActions.at(actionsListWidget->currentRow()).Value == "/")
    {
        rootPartition = "";
    }

    diskActions.remove(actionsListWidget->currentRow());
    actionsListWidget->takeItem(actionsListWidget->currentRow());
    return 0;
}

int diskPage::applyActions()
{
    for (int i =0; i < diskActions.size(); i++)
    {
        emit Status(actionsListWidget->itemAt(i, 0)->text(), BUSY);
        Partition p = (diskActions.at(i)).partition;
        if (diskActions.at(i).Action == PFORMAT)
        {
            for (int i =0; i < availableFileSystems.size(); i++)
            {

                if ( availableFileSystems.at(i).second == diskActions.at(i).Value)
                {
                    //execute command
                    QProcess format;
                    format.start(availableFileSystems.at(i).first + " " + p.getdevPath());
                    format.waitForFinished(800000); // 800 second ? enough ?

                }
            }
        }
        else if (diskActions.at(i).Action == PLABEL)
        {
            p.setLabel(diskActions.at(i).Value);
        }
        else if (diskActions.at(i).Action == PMOUNT)
        {
            mountPoint mp;
            mp.partition=p.getdevPath();

            int index = hasAction(p, PFORMAT);
            if ( index != -1 )
            {
                mp.fs="NONE";
            }
            else
            {
                mp.fs=diskActions.at(index).Value;
            }


            installationMountPoints.push_back(mp);
        }
        emit Status(tr("Done") + actionsListWidget->itemAt(i, 0)->text(), STATUS);

        // leave them for finding formatted filesystems for mounting and stuff...
        //diskActions.remove(i);
        //i--;
    }

    if (!rootPartition.isEmpty())
    {
        emit Done(true);
    }
    else
    {
        emit Status(tr("Please choose a root mount point"), ERROR);
    }

    return 0;
}


QString diskPage::parseCommand(QString command, QString part, QString oldString ="", QString newString ="")
{
    QString result = command;
    if(oldString != "" &&
       newString != "")
    {
        result = result.replace(oldString, newString);
    }
    result = result.replace("partition", part);
    return result;
}

int diskPage::formatPartition(Partition part, QString fs)
{
    PedFileSystemType* pfst = ped_file_system_type_get(fs.toStdString().c_str());

    //if (ped_file_system_create(&part.getPartedPartition()->geom, pfst, NULL) == NULL)
    if(ped_partition_set_system(part.getPartedPartition(), pfst))
    {
        actionProcess.start(parseCommand(formatTools[fs], part.getdevPath()));
        if(actionProcess.waitForStarted(1000) ||
           actionProcess.waitForFinished(10000))
        {
            return 0;
        }
        return 1;
    }

    return 0;
}

int diskPage::labelPartition(Partition part, QString label)
{
    if (!ped_partition_set_name(part.getPartedPartition(), label.toStdString().c_str()))
    {
        actionProcess.start(labelTools[label],  QStringList() << part.getdevPath());
        if(actionProcess.waitForStarted(1000) ||
           actionProcess.waitForFinished(10000))
        {
            return 0;
        }
        return 1;
    }
    return 0;
}

int diskPage::reset()
{
    actionsListWidget->clear();
    diskActions.clear();
    return 0;
}
