#ifndef TIMEPAGE_HPP
#define TIMEPAGE_HPP


#include <Pages/pageBase.hpp>
#include <ui_timepage.h>

class timePage : public pageBase, private Ui::timePage
{
    Q_OBJECT

public:
    explicit timePage(QWidget *parent = 0);
    int      initAll();
    QString  getDate();
    int      loadTimeZones();
    QString  getTimeZone();
    QString  getLocales();
    QString  getCountry();
    ~timePage();

private:
    int     loadLocales();
    int     saveLocales();

    QString localeFilePath;
};

#endif // TIMEPAGE_HPP
