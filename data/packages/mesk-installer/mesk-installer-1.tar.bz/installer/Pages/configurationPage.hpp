#ifndef CONFIGURATIONPAGE_HPP
#define CONFIGURATIONPAGE_HPP

#include <QWidget>
#include "pageBase.hpp"
#include "ui_configurationPage.h"

class configurationPage : public pageBase, private Ui::configurationPage
{
    Q_OBJECT
    
public:
    explicit configurationPage(QWidget *parent = 0);
    ~configurationPage();
    
private:
};


#endif // CONFIGURATIONPAGE_HPP
