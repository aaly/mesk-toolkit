#ifndef INSTALLATIONPAGE_HPP
#define INSTALLATIONPAGE_HPP

#include <Pages/pageBase.hpp>
#include "ui_installationPage.h"
#include <System/chroot.hpp>


class installationPage : public pageBase, private Ui::installationPage
{
    Q_OBJECT
    
public:
    explicit installationPage(QWidget *parent = 0);
    ~installationPage();
    int     initAll();
    
private:

    int install();
    int installPackages();
    int generateKernel();
    int generateLocales();

    int     initSlideShow();
    int slideStep;
    QVector<QPixmap> slides;
    QString slidesDir;

    QTimer* timer;
    int             setAction(const QString&);

    QString installationRoot;
    chroot*      Root;

private slots:
    int     slide();
};

#endif // INSTALLATIONPAGE_HPP
