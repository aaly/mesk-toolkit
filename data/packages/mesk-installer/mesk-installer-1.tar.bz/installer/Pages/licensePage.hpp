#ifndef LICENSEPAGE_H
#define LICENSEPAGE_H

#include "Pages/pageBase.hpp"
#include "ui_licensePage.h"

class licensePage : public pageBase, private Ui::licensePage
{
    Q_OBJECT

public:
    explicit licensePage(QWidget *parent = 0);
    ~licensePage();
    int     initAll();

private:
    QString licenseFilePath;
private slots:
    int setReady();
};

#endif // LICENSEPAGE_H
