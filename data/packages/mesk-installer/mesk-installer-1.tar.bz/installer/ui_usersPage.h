/********************************************************************************
** Form generated from reading UI file 'usersPage.ui'
**
** Created: Mon Jul 23 00:50:01 2012
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERSPAGE_H
#define UI_USERSPAGE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_usersPage
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *userInfoVerticalLayout;
    QHBoxLayout *nameHorizontalLayout;
    QLabel *nameLabel;
    QLineEdit *nameLineEdit;
    QLabel *userNameLabel;
    QLineEdit *userNameLineEdit;
    QHBoxLayout *passwordHorizontalLayout;
    QLabel *passwordLabel;
    QLineEdit *passwordLineEdit;
    QLabel *confirmPasswordlabel;
    QLineEdit *confirmPasswordLineEdit;
    QHBoxLayout *homeHorizontalLayout;
    QLabel *homeLabel;
    QLineEdit *homeLineEdit;
    QSpacerItem *homeHorizontalSpacer;
    QHBoxLayout *groupsHorizontalLayout;
    QLabel *groupsLabel;
    QSpacerItem *groupsHorizontalSpacer;
    QHBoxLayout *operationsHorizontalLayout;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *removeUserPushButton;
    QPushButton *addUserPushButton;
    QTableWidget *usersTableWidget;

    void setupUi(QWidget *usersPage)
    {
        if (usersPage->objectName().isEmpty())
            usersPage->setObjectName(QString::fromUtf8("usersPage"));
        usersPage->resize(600, 365);
        verticalLayout_2 = new QVBoxLayout(usersPage);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        userInfoVerticalLayout = new QVBoxLayout();
        userInfoVerticalLayout->setObjectName(QString::fromUtf8("userInfoVerticalLayout"));
        nameHorizontalLayout = new QHBoxLayout();
        nameHorizontalLayout->setObjectName(QString::fromUtf8("nameHorizontalLayout"));
        nameLabel = new QLabel(usersPage);
        nameLabel->setObjectName(QString::fromUtf8("nameLabel"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(1);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(nameLabel->sizePolicy().hasHeightForWidth());
        nameLabel->setSizePolicy(sizePolicy);

        nameHorizontalLayout->addWidget(nameLabel);

        nameLineEdit = new QLineEdit(usersPage);
        nameLineEdit->setObjectName(QString::fromUtf8("nameLineEdit"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(3);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(nameLineEdit->sizePolicy().hasHeightForWidth());
        nameLineEdit->setSizePolicy(sizePolicy1);

        nameHorizontalLayout->addWidget(nameLineEdit);

        userNameLabel = new QLabel(usersPage);
        userNameLabel->setObjectName(QString::fromUtf8("userNameLabel"));
        sizePolicy.setHeightForWidth(userNameLabel->sizePolicy().hasHeightForWidth());
        userNameLabel->setSizePolicy(sizePolicy);

        nameHorizontalLayout->addWidget(userNameLabel);

        userNameLineEdit = new QLineEdit(usersPage);
        userNameLineEdit->setObjectName(QString::fromUtf8("userNameLineEdit"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(4);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(userNameLineEdit->sizePolicy().hasHeightForWidth());
        userNameLineEdit->setSizePolicy(sizePolicy2);

        nameHorizontalLayout->addWidget(userNameLineEdit);


        userInfoVerticalLayout->addLayout(nameHorizontalLayout);

        passwordHorizontalLayout = new QHBoxLayout();
        passwordHorizontalLayout->setObjectName(QString::fromUtf8("passwordHorizontalLayout"));
        passwordLabel = new QLabel(usersPage);
        passwordLabel->setObjectName(QString::fromUtf8("passwordLabel"));
        sizePolicy.setHeightForWidth(passwordLabel->sizePolicy().hasHeightForWidth());
        passwordLabel->setSizePolicy(sizePolicy);

        passwordHorizontalLayout->addWidget(passwordLabel);

        passwordLineEdit = new QLineEdit(usersPage);
        passwordLineEdit->setObjectName(QString::fromUtf8("passwordLineEdit"));
        sizePolicy1.setHeightForWidth(passwordLineEdit->sizePolicy().hasHeightForWidth());
        passwordLineEdit->setSizePolicy(sizePolicy1);

        passwordHorizontalLayout->addWidget(passwordLineEdit);

        confirmPasswordlabel = new QLabel(usersPage);
        confirmPasswordlabel->setObjectName(QString::fromUtf8("confirmPasswordlabel"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(2);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(confirmPasswordlabel->sizePolicy().hasHeightForWidth());
        confirmPasswordlabel->setSizePolicy(sizePolicy3);

        passwordHorizontalLayout->addWidget(confirmPasswordlabel);

        confirmPasswordLineEdit = new QLineEdit(usersPage);
        confirmPasswordLineEdit->setObjectName(QString::fromUtf8("confirmPasswordLineEdit"));
        sizePolicy1.setHeightForWidth(confirmPasswordLineEdit->sizePolicy().hasHeightForWidth());
        confirmPasswordLineEdit->setSizePolicy(sizePolicy1);

        passwordHorizontalLayout->addWidget(confirmPasswordLineEdit);


        userInfoVerticalLayout->addLayout(passwordHorizontalLayout);

        homeHorizontalLayout = new QHBoxLayout();
        homeHorizontalLayout->setObjectName(QString::fromUtf8("homeHorizontalLayout"));
        homeLabel = new QLabel(usersPage);
        homeLabel->setObjectName(QString::fromUtf8("homeLabel"));
        sizePolicy.setHeightForWidth(homeLabel->sizePolicy().hasHeightForWidth());
        homeLabel->setSizePolicy(sizePolicy);

        homeHorizontalLayout->addWidget(homeLabel);

        homeLineEdit = new QLineEdit(usersPage);
        homeLineEdit->setObjectName(QString::fromUtf8("homeLineEdit"));
        sizePolicy1.setHeightForWidth(homeLineEdit->sizePolicy().hasHeightForWidth());
        homeLineEdit->setSizePolicy(sizePolicy1);

        homeHorizontalLayout->addWidget(homeLineEdit);

        homeHorizontalSpacer = new QSpacerItem(323, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        homeHorizontalLayout->addItem(homeHorizontalSpacer);


        userInfoVerticalLayout->addLayout(homeHorizontalLayout);

        groupsHorizontalLayout = new QHBoxLayout();
        groupsHorizontalLayout->setObjectName(QString::fromUtf8("groupsHorizontalLayout"));
        groupsLabel = new QLabel(usersPage);
        groupsLabel->setObjectName(QString::fromUtf8("groupsLabel"));
        sizePolicy.setHeightForWidth(groupsLabel->sizePolicy().hasHeightForWidth());
        groupsLabel->setSizePolicy(sizePolicy);

        groupsHorizontalLayout->addWidget(groupsLabel);

        groupsHorizontalSpacer = new QSpacerItem(323, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        groupsHorizontalLayout->addItem(groupsHorizontalSpacer);


        userInfoVerticalLayout->addLayout(groupsHorizontalLayout);

        operationsHorizontalLayout = new QHBoxLayout();
        operationsHorizontalLayout->setObjectName(QString::fromUtf8("operationsHorizontalLayout"));
        horizontalSpacer_3 = new QSpacerItem(262, 17, QSizePolicy::Expanding, QSizePolicy::Minimum);

        operationsHorizontalLayout->addItem(horizontalSpacer_3);

        removeUserPushButton = new QPushButton(usersPage);
        removeUserPushButton->setObjectName(QString::fromUtf8("removeUserPushButton"));
        QSizePolicy sizePolicy4(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(1);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(removeUserPushButton->sizePolicy().hasHeightForWidth());
        removeUserPushButton->setSizePolicy(sizePolicy4);

        operationsHorizontalLayout->addWidget(removeUserPushButton);

        addUserPushButton = new QPushButton(usersPage);
        addUserPushButton->setObjectName(QString::fromUtf8("addUserPushButton"));
        sizePolicy4.setHeightForWidth(addUserPushButton->sizePolicy().hasHeightForWidth());
        addUserPushButton->setSizePolicy(sizePolicy4);

        operationsHorizontalLayout->addWidget(addUserPushButton);


        userInfoVerticalLayout->addLayout(operationsHorizontalLayout);


        verticalLayout_2->addLayout(userInfoVerticalLayout);

        usersTableWidget = new QTableWidget(usersPage);
        if (usersTableWidget->columnCount() < 4)
            usersTableWidget->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        usersTableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        usersTableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        usersTableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        usersTableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        usersTableWidget->setObjectName(QString::fromUtf8("usersTableWidget"));

        verticalLayout_2->addWidget(usersTableWidget);

#ifndef QT_NO_SHORTCUT
        nameLabel->setBuddy(nameLineEdit);
        userNameLabel->setBuddy(userNameLineEdit);
        passwordLabel->setBuddy(passwordLineEdit);
        confirmPasswordlabel->setBuddy(confirmPasswordLineEdit);
        homeLabel->setBuddy(homeLineEdit);
#endif // QT_NO_SHORTCUT

        retranslateUi(usersPage);

        QMetaObject::connectSlotsByName(usersPage);
    } // setupUi

    void retranslateUi(QWidget *usersPage)
    {
        usersPage->setWindowTitle(QApplication::translate("usersPage", "Form", 0, QApplication::UnicodeUTF8));
        nameLabel->setText(QApplication::translate("usersPage", "&Name", 0, QApplication::UnicodeUTF8));
        userNameLabel->setText(QApplication::translate("usersPage", "&Username", 0, QApplication::UnicodeUTF8));
        passwordLabel->setText(QApplication::translate("usersPage", "&Password", 0, QApplication::UnicodeUTF8));
        confirmPasswordlabel->setText(QApplication::translate("usersPage", "&Confirm password", 0, QApplication::UnicodeUTF8));
        homeLabel->setText(QApplication::translate("usersPage", "&Home", 0, QApplication::UnicodeUTF8));
        homeLineEdit->setText(QString());
        groupsLabel->setText(QApplication::translate("usersPage", "&Groups", 0, QApplication::UnicodeUTF8));
        removeUserPushButton->setText(QApplication::translate("usersPage", "&Remove", 0, QApplication::UnicodeUTF8));
        addUserPushButton->setText(QApplication::translate("usersPage", "&Add", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = usersTableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("usersPage", "Username", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = usersTableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("usersPage", "Name", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = usersTableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("usersPage", "Home", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem3 = usersTableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("usersPage", "Groups", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class usersPage: public Ui_usersPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERSPAGE_H
