/********************************************************************************
** Form generated from reading UI file 'releasePage.ui'
**
** Created: Mon Jul 23 00:50:01 2012
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RELEASEPAGE_H
#define UI_RELEASEPAGE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_releasePage
{
public:
    QVBoxLayout *verticalLayout;
    QTextEdit *releaseTextEdit;

    void setupUi(QWidget *releasePage)
    {
        if (releasePage->objectName().isEmpty())
            releasePage->setObjectName(QString::fromUtf8("releasePage"));
        releasePage->resize(400, 300);
        verticalLayout = new QVBoxLayout(releasePage);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        releaseTextEdit = new QTextEdit(releasePage);
        releaseTextEdit->setObjectName(QString::fromUtf8("releaseTextEdit"));

        verticalLayout->addWidget(releaseTextEdit);


        retranslateUi(releasePage);

        QMetaObject::connectSlotsByName(releasePage);
    } // setupUi

    void retranslateUi(QWidget *releasePage)
    {
        releasePage->setWindowTitle(QApplication::translate("releasePage", "Form", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class releasePage: public Ui_releasePage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RELEASEPAGE_H
