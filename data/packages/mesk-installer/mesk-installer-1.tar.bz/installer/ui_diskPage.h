/********************************************************************************
** Form generated from reading UI file 'diskPage.ui'
**
** Created: Mon Jul 23 00:50:01 2012
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DISKPAGE_H
#define UI_DISKPAGE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QFrame>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTreeView>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_diskPage
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QComboBox *disksList;
    QSpacerItem *horizontalSpacer_2;
    QTreeView *partitionsTreeView;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLineEdit *labelLineEdit;
    QFrame *line_2;
    QLabel *label_3;
    QComboBox *mountComboBox;
    QFrame *line;
    QCheckBox *formatCheckBox;
    QComboBox *filesystemComboBox;
    QPushButton *addPushButton;
    QFrame *line_3;
    QLabel *label_4;
    QListWidget *actionsListWidget;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *removePushButton;
    QSpacerItem *horizontalSpacer;
    QPushButton *resetPushButton;
    QPushButton *applyPushButton;

    void setupUi(QWidget *diskPage)
    {
        if (diskPage->objectName().isEmpty())
            diskPage->setObjectName(QString::fromUtf8("diskPage"));
        diskPage->resize(569, 433);
        verticalLayout = new QVBoxLayout(diskPage);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(diskPage);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        disksList = new QComboBox(diskPage);
        disksList->setObjectName(QString::fromUtf8("disksList"));

        horizontalLayout->addWidget(disksList);

        horizontalSpacer_2 = new QSpacerItem(418, 18, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout);

        partitionsTreeView = new QTreeView(diskPage);
        partitionsTreeView->setObjectName(QString::fromUtf8("partitionsTreeView"));

        verticalLayout->addWidget(partitionsTreeView);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(diskPage);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(label_2);

        labelLineEdit = new QLineEdit(diskPage);
        labelLineEdit->setObjectName(QString::fromUtf8("labelLineEdit"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(labelLineEdit->sizePolicy().hasHeightForWidth());
        labelLineEdit->setSizePolicy(sizePolicy1);

        horizontalLayout_2->addWidget(labelLineEdit);

        line_2 = new QFrame(diskPage);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);

        horizontalLayout_2->addWidget(line_2);

        label_3 = new QLabel(diskPage);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        sizePolicy.setHeightForWidth(label_3->sizePolicy().hasHeightForWidth());
        label_3->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(label_3);

        mountComboBox = new QComboBox(diskPage);
        mountComboBox->setObjectName(QString::fromUtf8("mountComboBox"));
        sizePolicy1.setHeightForWidth(mountComboBox->sizePolicy().hasHeightForWidth());
        mountComboBox->setSizePolicy(sizePolicy1);

        horizontalLayout_2->addWidget(mountComboBox);

        line = new QFrame(diskPage);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);

        horizontalLayout_2->addWidget(line);

        formatCheckBox = new QCheckBox(diskPage);
        formatCheckBox->setObjectName(QString::fromUtf8("formatCheckBox"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(formatCheckBox->sizePolicy().hasHeightForWidth());
        formatCheckBox->setSizePolicy(sizePolicy2);

        horizontalLayout_2->addWidget(formatCheckBox);

        filesystemComboBox = new QComboBox(diskPage);
        filesystemComboBox->setObjectName(QString::fromUtf8("filesystemComboBox"));
        sizePolicy1.setHeightForWidth(filesystemComboBox->sizePolicy().hasHeightForWidth());
        filesystemComboBox->setSizePolicy(sizePolicy1);

        horizontalLayout_2->addWidget(filesystemComboBox);

        addPushButton = new QPushButton(diskPage);
        addPushButton->setObjectName(QString::fromUtf8("addPushButton"));

        horizontalLayout_2->addWidget(addPushButton);


        verticalLayout->addLayout(horizontalLayout_2);

        line_3 = new QFrame(diskPage);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        sizePolicy1.setHeightForWidth(line_3->sizePolicy().hasHeightForWidth());
        line_3->setSizePolicy(sizePolicy1);
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_3);

        label_4 = new QLabel(diskPage);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy3);

        verticalLayout->addWidget(label_4);

        actionsListWidget = new QListWidget(diskPage);
        actionsListWidget->setObjectName(QString::fromUtf8("actionsListWidget"));

        verticalLayout->addWidget(actionsListWidget);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        removePushButton = new QPushButton(diskPage);
        removePushButton->setObjectName(QString::fromUtf8("removePushButton"));

        horizontalLayout_3->addWidget(removePushButton);

        horizontalSpacer = new QSpacerItem(258, 21, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        resetPushButton = new QPushButton(diskPage);
        resetPushButton->setObjectName(QString::fromUtf8("resetPushButton"));

        horizontalLayout_3->addWidget(resetPushButton);

        applyPushButton = new QPushButton(diskPage);
        applyPushButton->setObjectName(QString::fromUtf8("applyPushButton"));

        horizontalLayout_3->addWidget(applyPushButton);


        verticalLayout->addLayout(horizontalLayout_3);


        retranslateUi(diskPage);

        QMetaObject::connectSlotsByName(diskPage);
    } // setupUi

    void retranslateUi(QWidget *diskPage)
    {
        diskPage->setWindowTitle(QApplication::translate("diskPage", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("diskPage", "Disks :", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("diskPage", "Label :", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("diskPage", "Mountpoint :", 0, QApplication::UnicodeUTF8));
        formatCheckBox->setText(QApplication::translate("diskPage", "Format", 0, QApplication::UnicodeUTF8));
        addPushButton->setText(QApplication::translate("diskPage", "Ok", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("diskPage", "Actions :       ", 0, QApplication::UnicodeUTF8));
        removePushButton->setText(QApplication::translate("diskPage", "Remove", 0, QApplication::UnicodeUTF8));
        resetPushButton->setText(QApplication::translate("diskPage", "Reset", 0, QApplication::UnicodeUTF8));
        applyPushButton->setText(QApplication::translate("diskPage", "Apply", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class diskPage: public Ui_diskPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DISKPAGE_H
