#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Pages/pageBase.hpp"
#include "Pages/packagesPage.hpp"
#include "Pages/diskPage.hpp"
#include "Pages/licensePage.hpp"
#include "Pages/releasePage.hpp"
#include "Pages/userspage.hpp"
#include <Pages/loadingpage.hpp>
#include <Pages/timepage.hpp>
#include <Pages/configurationPage.hpp>
#include <Pages/installationPage.hpp>

#include <QGraphicsOpacityEffect>
#include <QPropertyAnimation>

#include <QMessageBox>

#include <unistd.h> // getuid;

#include <QIcon>
#include <QPixmap>

#include <iostream>
using namespace std;
// use setpriority(2) - Linux man page


// only enabe next when the current page is ready or done

MainWindow::MainWindow(QWidget *parent) :
        QMainWindow(parent,0)
{
    if (getuid() != 0)
    {
        QMessageBox::critical(this, "Need Root privilages", tr("The installer must be ran by the root user"));
        exit(1);
    }

    setupUi(this);
    pages = new QVector<pageBase*>();
    step = 0;
    showFullScreen();

    messageIconWidth = 16;
    messageIconHeight = 16;
    currentPage = 0;
    pageReady = false;

    helpTextEdit->hide();
    //

    helpPushButton->setIcon(QIcon(getApplicationFile("/Icons/help.png")).pixmap(messageIconWidth, messageIconHeight));
    nextPushButton->setIcon(QIcon(getApplicationFile("/Icons/next.png")).pixmap(messageIconWidth, messageIconHeight));
    previousPushButton->setIcon(QIcon(getApplicationFile("/Icons/prev.png")).pixmap(messageIconWidth, messageIconHeight));
    exitPushButton->setIcon(QIcon(getApplicationFile("/Icons/exit.png")).pixmap(messageIconWidth, messageIconHeight));

    loadingpage = new loadingPage(this);
    //loadingpage->pageName = "License1.";
    //loadingpage->pageHelpMessage = "Please review License";
    //loadingpage->pageGroup = "License";
    //loadingpage->pageIcon = ":/Icons/License1.png";
    //addPage(loadingpage);

    //loadingpage->setIcon("Icons/critical.png");
    //loadingpage->setIconEffect(FADEIN);
    //loadingpage->setMessageEffect(FADEIN);


    releasePage* rpage = new releasePage(this);
    rpage->pageName = "Release.";
    rpage->pageHelpMessage = "Please review Release";
    rpage->pageGroup = "Release";
    rpage->pageIcon = getApplicationFile("/Icons/Release.png");
    addPage(rpage);


    licensePage* lpage = new licensePage(this);
    lpage->pageName = "License.";
    lpage->pageHelpMessage = "Please review License";
    lpage->pageGroup = "License";
    lpage->pageIcon = getApplicationFile("/Icons/License.png");
    addPage(lpage);


    timePage* tpage = new timePage(this);
    tpage->pageName = "Time.";
    tpage->pageHelpMessage = "Time review License";
    tpage->pageGroup = "Time";
    tpage->pageIcon = getApplicationFile("/Icons/Time.png");
    addPage(tpage);

    packagesPage* ppage = new packagesPage(this);
    ppage->pageName = "Packages.";
    ppage->pageHelpMessage = "Packages review License";
    ppage->pageGroup = "Packages";
    ppage->pageIcon = getApplicationFile("/Icons/Packages.png");
    addPage(ppage);


    diskPage* dpage = new diskPage(this);
    dpage->pageName = "Disk management.";
    dpage->pageHelpMessage = "Disk management review License";
    dpage->pageGroup = "Disk management";
    dpage->pageIcon = getApplicationFile("/Icons/Disks.png");
    addPage(dpage);

    installationPage* ipage = new installationPage(this);
    ipage->pageName = "Installation.";
    ipage->pageHelpMessage = "Installation";
    ipage->pageGroup = "Installation";
    ipage->pageIcon = getApplicationFile("/Icons/Installation.png");
    ipage->Depend("Time",tpage);
    ipage->Depend("Packages",ppage);
    ipage->Depend("Disk",dpage);
    addPage(ipage);

    usersPage* upage = new usersPage(this);
    upage->pageName = "Users management.";
    upage->pageHelpMessage = "Users management";
    upage->pageGroup = "Users management";
    upage->pageIcon = getApplicationFile("/Icons/Users.png");
    addPage(upage);

    configurationPage* cpage = new configurationPage(this);
    cpage->pageName = "Confguration.";
    cpage->pageHelpMessage = "Confguration";
    cpage->pageGroup = "Confguration";
    cpage->pageIcon = getApplicationFile("/Icons/Confguration.png");
    addPage(cpage);

    //bootloaderPage* blpage = new bootloaderPage(this);
    //blpage->pageName = "BootLoader.";
    //blpage->pageHelpMessage = "Confguration";
    //blpage->pageGroup = "Confguration";
    //blpage->pageIcon = ":/Icons/Confguration.png";
    //addPage(blpage);


    loadingPage* finishedPage = new loadingPage(this);
    finishedPage->setIcon(getApplicationFile("/Icons/done.png"));
    finishedPage->setIconEffect(FADEIN);
    finishedPage->setMessage("finished installation");
    finishedPage->setMessageEffect(FADEIN);
    finishedPage->pageName = "Finish.";
    finishedPage->pageHelpMessage = "Finish";
    finishedPage->pageGroup = "Finish";
    finishedPage->pageIcon = getApplicationFile("/Icons/done.png");
    addPage(finishedPage);


    stackedWidget->addWidget(loadingpage);
    //stackedWidget->setCurrentWidget(loadingpage);

    connect(helpPushButton, SIGNAL(clicked()), this, SLOT(showHelp()));
    connect(nextPushButton, SIGNAL(clicked()), this, SLOT(nextPage()));
    connect(previousPushButton, SIGNAL(clicked()), this, SLOT(prevPage()));
    connect(loadingpage, SIGNAL(finished()), this, SLOT(changePage()));

    prevPage();
    changePage();

}

MainWindow::~MainWindow()
{
    delete pages;
}

int MainWindow::addMessage(QString message, int type)
{
    if(type == BUSY)
    {
        if(stackedWidget->currentWidget() != loadingpage)
        {
            stackedWidget->setCurrentWidget(loadingpage);
        }

        loadingpage->setMessage(message);
        loadingpage->setIcon(getApplicationFile("/Icons/busy.png"));
        return 0;

    }

    QLabel* label = new QLabel(this);
    label->setTextFormat(Qt::RichText);
    label->show();

    QString icon = "<img height=HEIGHT width=WIDTH src=\"PATH\">";
    icon.replace("WIDTH",QString::number(messageIconWidth));
    icon.replace("HEIGHT",QString::number(messageIconHeight));

    if (type == ERROR)
    {
       icon= icon.replace("PATH", getApplicationFile("/Icons/error.png"));
    }
    else if (type == INFORMATION)
    {
       icon= icon.replace("PATH", getApplicationFile("/Icons/information.png"));
    }
    else if (type == CRITICAL)
    {
       icon= icon.replace("PATH", getApplicationFile("/Icons/critical.png"));
    }
    else if (type == STATUS)
    {
      icon= icon.replace("PATH", getApplicationFile("/Icons/status.png"));
    }
    label->setText(icon+" "+message);


    QGraphicsOpacityEffect* opacityEffect = new QGraphicsOpacityEffect(this);
    opacityEffect->setOpacity(0);
    label->setGraphicsEffect(opacityEffect);
    QPropertyAnimation* anim = new QPropertyAnimation(this);
    anim->setTargetObject(opacityEffect);
    anim->setPropertyName("opacity");
    anim->setDuration(9000);
    anim->setStartValue(opacityEffect->opacity());
    anim->setEndValue(1);
    anim->setEasingCurve(QEasingCurve::OutQuad);

    messagesVerticalLayout->addWidget(label);

    anim->start(QAbstractAnimation::DeleteWhenStopped);

    return 0;

}

int MainWindow::showHelp()
{
    QGraphicsOpacityEffect* opacityEffect = new QGraphicsOpacityEffect(this);

    helpTextEdit->setGraphicsEffect(opacityEffect);
    //helpTextEdit->setText("");
    QPropertyAnimation* anim = new QPropertyAnimation(this);

    if(helpTextEdit->isHidden())
    {
        opacityEffect->setOpacity(1);
        anim->setEndValue(0);
        helpPushButton->setText("&Hide Help");
        helpTextEdit->show();
    }
    else
    {
        opacityEffect->setOpacity(0);
        anim->setEndValue(1);
        helpPushButton->setText("&Show Help");
        helpTextEdit->hide();
    }

    anim->setTargetObject(opacityEffect);
    anim->setPropertyName("opacity");
    anim->setDuration(3000);
    anim->setStartValue(opacityEffect->opacity());
    anim->setEasingCurve(QEasingCurve::InBounce);
    anim->start(QAbstractAnimation::DeleteWhenStopped);

    return 0;
}


int MainWindow::animateWidget(QWidget* widget, bool hide, int effect)
{
    if(!widget)
    {
        return 1;
    }

    if(effect == FADING)
    {
        QGraphicsOpacityEffect* opacityEffect = new QGraphicsOpacityEffect(this);
        opacityEffect->setOpacity(0);
        widget->setGraphicsEffect(opacityEffect);
        QPropertyAnimation* anim = new QPropertyAnimation(this);
        anim->setTargetObject(opacityEffect);
        anim->setPropertyName("opacity");
        anim->setDuration(9000);
        anim->setStartValue(opacityEffect->opacity());
        anim->setEndValue(1);
        anim->setEasingCurve(QEasingCurve::OutQuad);
        anim->start(QAbstractAnimation::DeleteWhenStopped);
    }


    return 0;
}


int MainWindow::addPage(pageBase* page)
{
    if (page == NULL)
    {
        return 1;
    }

    stackedWidget->addWidget(page);
    pages->push_back(page);
    //stepsLabel->setText("test");

    stepsLabel->setText(stepsLabel->text() +
                        QString ("<img align=absmiddle height=30 width=30 src=\"PATH\">").replace("PATH", page->pageIcon)
                        +" "
                        +QString(page->pageName) + "<br> <br>");

    connect(page, SIGNAL(Status(QString,int)), this, SLOT(addMessage(QString,int)));
    connect(page, SIGNAL(Done(bool)), nextPushButton, SLOT(setEnabled(bool)));
    connect(page, SIGNAL(Ready()), loadingpage, SLOT(finish()));

    return 1;
}

int MainWindow::prevPage()
{

    stepsLabel->setText(stepsLabel->text().replace(getApplicationFile("/Icons/current.png"), pages->at(step)->pageIcon));

    nextPushButton->setEnabled(true);
    if (step == 0)
    {
        previousPushButton->setEnabled(false);
        return 1;
    }
    if (step == 1)
    {
        previousPushButton->setEnabled(false);
    }

    step--;

    changePage();

    return 0;
}

int MainWindow::nextPage()
{
    nextPushButton->setDisabled(true);
    stepsLabel->setText(stepsLabel->text().replace(getApplicationFile("/Icons/current.png"), pages->at(step)->pageIcon));

    previousPushButton->setEnabled(true);
    if (step == pages->size()-1)
    {
        return 1;
    }
    else if (step == pages->size()-2)
    {
        nextPushButton->setEnabled(false);
    }
    step++;

    changePage();

    return 0;
}

int MainWindow::changePage()
{
    stackedWidget->setCurrentWidget(pages->at(step));
    helpTextEdit->setText(pages->at(step)->pageHelpMessage);

    if (!pages->at(step)->init)
    {
        pages->at(step)->initAll();
        cout << "Step: " << step << endl << flush;
    }

    QString steps = stepsLabel->text();
    steps.replace(pages->at(step)->pageIcon, QString(getApplicationFile("/Icons/current.png")));
    //steps.replace(pages->at(step)->pageName, QString("<font color=\"red\">" + pages->at(step)->pageName + "</font>"));
    stepsLabel->setText(steps);



    return 0;
}

