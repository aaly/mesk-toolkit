/********************************************************************************
** Form generated from reading UI file 'configurationPage.ui'
**
** Created: Mon Jul 23 00:50:01 2012
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONFIGURATIONPAGE_H
#define UI_CONFIGURATIONPAGE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_configurationPage
{
public:

    void setupUi(QWidget *configurationPage)
    {
        if (configurationPage->objectName().isEmpty())
            configurationPage->setObjectName(QString::fromUtf8("configurationPage"));
        configurationPage->resize(400, 300);

        retranslateUi(configurationPage);

        QMetaObject::connectSlotsByName(configurationPage);
    } // setupUi

    void retranslateUi(QWidget *configurationPage)
    {
        configurationPage->setWindowTitle(QApplication::translate("configurationPage", "Form", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class configurationPage: public Ui_configurationPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONFIGURATIONPAGE_H
