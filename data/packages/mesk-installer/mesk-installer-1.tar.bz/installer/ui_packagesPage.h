/********************************************************************************
** Form generated from reading UI file 'packagesPage.ui'
**
** Created: Mon Jul 23 00:50:01 2012
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PACKAGESPAGE_H
#define UI_PACKAGESPAGE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_packagesPage
{
public:
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QListWidget *reposListWidget;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_2;
    QListWidget *packagesListWidget;
    QTextEdit *packageDescriptionTextEdit;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *resetPushButton;
    QSpacerItem *horizontalSpacer;

    void setupUi(QWidget *packagesPage)
    {
        if (packagesPage->objectName().isEmpty())
            packagesPage->setObjectName(QString::fromUtf8("packagesPage"));
        packagesPage->resize(596, 500);
        verticalLayout_4 = new QVBoxLayout(packagesPage);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(packagesPage);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        reposListWidget = new QListWidget(packagesPage);
        reposListWidget->setObjectName(QString::fromUtf8("reposListWidget"));

        verticalLayout->addWidget(reposListWidget);


        horizontalLayout->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setSizeConstraint(QLayout::SetMaximumSize);
        label_2 = new QLabel(packagesPage);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_2->addWidget(label_2);

        packagesListWidget = new QListWidget(packagesPage);
        packagesListWidget->setObjectName(QString::fromUtf8("packagesListWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(packagesListWidget->sizePolicy().hasHeightForWidth());
        packagesListWidget->setSizePolicy(sizePolicy);

        verticalLayout_2->addWidget(packagesListWidget);


        horizontalLayout->addLayout(verticalLayout_2);

        horizontalLayout->setStretch(0, 50);
        horizontalLayout->setStretch(1, 100);

        verticalLayout_3->addLayout(horizontalLayout);

        packageDescriptionTextEdit = new QTextEdit(packagesPage);
        packageDescriptionTextEdit->setObjectName(QString::fromUtf8("packageDescriptionTextEdit"));
        packageDescriptionTextEdit->setReadOnly(true);

        verticalLayout_3->addWidget(packageDescriptionTextEdit);


        verticalLayout_4->addLayout(verticalLayout_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        resetPushButton = new QPushButton(packagesPage);
        resetPushButton->setObjectName(QString::fromUtf8("resetPushButton"));

        horizontalLayout_2->addWidget(resetPushButton);

        horizontalSpacer = new QSpacerItem(388, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);


        verticalLayout_4->addLayout(horizontalLayout_2);


        retranslateUi(packagesPage);

        QMetaObject::connectSlotsByName(packagesPage);
    } // setupUi

    void retranslateUi(QWidget *packagesPage)
    {
        packagesPage->setWindowTitle(QApplication::translate("packagesPage", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("packagesPage", "Repos", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("packagesPage", "Packages", 0, QApplication::UnicodeUTF8));
        resetPushButton->setText(QApplication::translate("packagesPage", "&Reset Selection", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class packagesPage: public Ui_packagesPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PACKAGESPAGE_H
