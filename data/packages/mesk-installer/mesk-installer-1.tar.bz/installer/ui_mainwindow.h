/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Mon Jul 23 00:50:01 2012
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QStackedWidget>
#include <QtGui/QStatusBar>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout_3;
    QFrame *frame;
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QSpacerItem *verticalSpacer;
    QLabel *meskLogoLabel;
    QLabel *stepsLabel;
    QFrame *line;
    QVBoxLayout *verticalLayout_2;
    QStackedWidget *stackedWidget;
    QWidget *page_3;
    QWidget *page_4;
    QVBoxLayout *messagesVerticalLayout;
    QFrame *line_3;
    QTextEdit *helpTextEdit;
    QPushButton *helpPushButton;
    QVBoxLayout *verticalLayout;
    QFrame *line_7;
    QSpacerItem *verticalSpacer_4;
    QPushButton *previousPushButton;
    QPushButton *nextPushButton;
    QSpacerItem *verticalSpacer_5;
    QPushButton *exitPushButton;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(862, 683);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout_3 = new QVBoxLayout(centralWidget);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        frame = new QFrame(centralWidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy);
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        gridLayout_2 = new QGridLayout(frame);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        verticalSpacer = new QSpacerItem(20, 247, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 2, 0, 1, 1);

        meskLogoLabel = new QLabel(frame);
        meskLogoLabel->setObjectName(QString::fromUtf8("meskLogoLabel"));

        gridLayout->addWidget(meskLogoLabel, 0, 0, 1, 2);

        stepsLabel = new QLabel(frame);
        stepsLabel->setObjectName(QString::fromUtf8("stepsLabel"));

        gridLayout->addWidget(stepsLabel, 1, 0, 1, 1);

        gridLayout->setRowStretch(0, 2);

        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);

        line = new QFrame(frame);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);

        gridLayout_2->addWidget(line, 0, 1, 2, 1);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        stackedWidget = new QStackedWidget(frame);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(14);
        sizePolicy1.setHeightForWidth(stackedWidget->sizePolicy().hasHeightForWidth());
        stackedWidget->setSizePolicy(sizePolicy1);
        page_3 = new QWidget();
        page_3->setObjectName(QString::fromUtf8("page_3"));
        stackedWidget->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName(QString::fromUtf8("page_4"));
        stackedWidget->addWidget(page_4);

        verticalLayout_2->addWidget(stackedWidget);

        messagesVerticalLayout = new QVBoxLayout();
        messagesVerticalLayout->setSpacing(6);
        messagesVerticalLayout->setObjectName(QString::fromUtf8("messagesVerticalLayout"));

        verticalLayout_2->addLayout(messagesVerticalLayout);

        line_3 = new QFrame(frame);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_3);

        helpTextEdit = new QTextEdit(frame);
        helpTextEdit->setObjectName(QString::fromUtf8("helpTextEdit"));
        helpTextEdit->setEnabled(true);
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(170);
        sizePolicy2.setVerticalStretch(4);
        sizePolicy2.setHeightForWidth(helpTextEdit->sizePolicy().hasHeightForWidth());
        helpTextEdit->setSizePolicy(sizePolicy2);
        helpTextEdit->setMaximumSize(QSize(16777215, 100));
        helpTextEdit->setFrameShape(QFrame::NoFrame);
        helpTextEdit->setFrameShadow(QFrame::Plain);
        helpTextEdit->setReadOnly(true);

        verticalLayout_2->addWidget(helpTextEdit);

        helpPushButton = new QPushButton(frame);
        helpPushButton->setObjectName(QString::fromUtf8("helpPushButton"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(helpPushButton->sizePolicy().hasHeightForWidth());
        helpPushButton->setSizePolicy(sizePolicy3);

        verticalLayout_2->addWidget(helpPushButton);


        gridLayout_2->addLayout(verticalLayout_2, 0, 2, 2, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        line_7 = new QFrame(frame);
        line_7->setObjectName(QString::fromUtf8("line_7"));
        line_7->setFrameShape(QFrame::HLine);
        line_7->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_7);

        verticalSpacer_4 = new QSpacerItem(17, 38, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_4);

        previousPushButton = new QPushButton(frame);
        previousPushButton->setObjectName(QString::fromUtf8("previousPushButton"));

        verticalLayout->addWidget(previousPushButton);

        nextPushButton = new QPushButton(frame);
        nextPushButton->setObjectName(QString::fromUtf8("nextPushButton"));

        verticalLayout->addWidget(nextPushButton);

        verticalSpacer_5 = new QSpacerItem(17, 8, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_5);

        exitPushButton = new QPushButton(frame);
        exitPushButton->setObjectName(QString::fromUtf8("exitPushButton"));
        QSizePolicy sizePolicy4(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(6);
        sizePolicy4.setHeightForWidth(exitPushButton->sizePolicy().hasHeightForWidth());
        exitPushButton->setSizePolicy(sizePolicy4);

        verticalLayout->addWidget(exitPushButton);


        gridLayout_2->addLayout(verticalLayout, 1, 0, 1, 1);


        verticalLayout_3->addWidget(frame);

        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);
        QObject::connect(exitPushButton, SIGNAL(clicked()), MainWindow, SLOT(close()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        meskLogoLabel->setText(QString());
        stepsLabel->setText(QString());
        helpPushButton->setText(QApplication::translate("MainWindow", "&Show Help", 0, QApplication::UnicodeUTF8));
        previousPushButton->setText(QApplication::translate("MainWindow", "&Previous", 0, QApplication::UnicodeUTF8));
        nextPushButton->setText(QApplication::translate("MainWindow", "&Next", 0, QApplication::UnicodeUTF8));
        exitPushButton->setText(QApplication::translate("MainWindow", "&Exit", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
