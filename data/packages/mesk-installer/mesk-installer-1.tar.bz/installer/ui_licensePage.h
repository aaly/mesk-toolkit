/********************************************************************************
** Form generated from reading UI file 'licensePage.ui'
**
** Created: Mon Jul 23 00:50:01 2012
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LICENSEPAGE_H
#define UI_LICENSEPAGE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QHeaderView>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_licensePage
{
public:
    QVBoxLayout *verticalLayout;
    QTextEdit *licenseTextEdit;
    QCheckBox *agreeCheckBox;

    void setupUi(QWidget *licensePage)
    {
        if (licensePage->objectName().isEmpty())
            licensePage->setObjectName(QString::fromUtf8("licensePage"));
        licensePage->resize(400, 300);
        verticalLayout = new QVBoxLayout(licensePage);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        licenseTextEdit = new QTextEdit(licensePage);
        licenseTextEdit->setObjectName(QString::fromUtf8("licenseTextEdit"));

        verticalLayout->addWidget(licenseTextEdit);

        agreeCheckBox = new QCheckBox(licensePage);
        agreeCheckBox->setObjectName(QString::fromUtf8("agreeCheckBox"));

        verticalLayout->addWidget(agreeCheckBox);


        retranslateUi(licensePage);

        QMetaObject::connectSlotsByName(licensePage);
    } // setupUi

    void retranslateUi(QWidget *licensePage)
    {
        licensePage->setWindowTitle(QApplication::translate("licensePage", "Form", 0, QApplication::UnicodeUTF8));
        agreeCheckBox->setText(QApplication::translate("licensePage", "Agree", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class licensePage: public Ui_licensePage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LICENSEPAGE_H
